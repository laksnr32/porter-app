import SectionHeader from './SectionHeader'
import TabHeader from './TabHeader'

export { SectionHeader, TabHeader }

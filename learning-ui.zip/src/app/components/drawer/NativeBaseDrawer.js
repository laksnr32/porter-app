import React from "react";
import { View } from "react-native";
import { Container, Content, Text, List, ListItem } from "native-base";
import { gradientPrimary, gradientSecondary,drawerItemStyle } from 'styles/common';
import { LinearGradient } from 'expo-linear-gradient';

const routes = ["Home", "Chat", "Profile"];

export default class NativeBaseDrawer extends React.Component {
  render() {    
    return (
      <Container>
        <LinearGradient
          colors={[`${gradientPrimary}95`, `${gradientSecondary}70`]}
          style={{
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            height: '100%',
          }}          
        />
        <View style={{ flex: 1 }}>             
          <List
            dataArray={this.props.items.map(e => e.routeName)}
            keyExtractor={(item, index) => `${index}`}
            renderRow={(data) => {
              return (
                <ListItem  
                  style={{borderBottomWidth: 0.5, borderBottomColor: this.props.inactiveTintColor}} 
                  noIndent               
                  button
                  onPress={() => this.props.navigation.navigate(data)}>                    
                  <Text style={{ ...drawerItemStyle, color: (this.props.activeItemKey === data ? this.props.activeTintColor : this.props.inactiveTintColor ),  }}>{data}</Text>
                </ListItem>
              );
            }}
          />
        </View>
      </Container>
    );
  }
}
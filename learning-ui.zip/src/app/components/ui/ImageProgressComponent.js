import React from 'react'
import PropTypes from 'prop-types'
import { Image } from 'react-native'

export default function ImageProgressComponent({
  photoURL,
  imageStyle,
  style,
  resizeMode
}) {
  return (
    <Image
      style={{ ...style, ...imageStyle }}
      source={{ uri: photoURL }}
      imageStyle={imageStyle}
      resizeMode={resizeMode}
    />
  )
}

ImageProgressComponent.propTypes = {
  photoURL: PropTypes.string.isRequired,
  imageStyle: PropTypes.object,
  style: PropTypes.object.isRequired,
  resizeMode: PropTypes.string
}
ImageProgressComponent.defaultProps = {
  resizeMode: 'contain'
}

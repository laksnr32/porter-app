import CourseCategoriesGridView from './CourseCategoriesGridView'
import MyCoursesGridView from './MyCoursesGridView'

export { CourseCategoriesGridView, MyCoursesGridView }

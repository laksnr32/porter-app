import React from 'react'
import PropTypes from 'prop-types'
import { MaterialCommunityIcons } from '@expo/vector-icons'
import styled from 'styled-components/native'

export const Wrapper = styled.View`
  flex: 1;
  padding: 16px;
  justify-content: center;
  align-items: center;
`

const iconWrapperDims = 80
export const IconWrapper = styled.TouchableOpacity`
  width: ${iconWrapperDims};
  height: ${iconWrapperDims};
  justify-content: center;
  align-items: center;
  border-radius: ${iconWrapperDims / 2};
  background-color: ${props => props.bgColor};
`

export const Icon = styled(MaterialCommunityIcons).attrs(props => ({
  size: 30,
  color: props.iconColor,
}))``

export const Title = styled.Text.attrs({
  numberOfLines: 1
})`
  font-family: 'SFProTextRegular';
  font-size: 15;
  margin-top: 8;
`

export default function CourseCategoryGridItem({ icon, title, onPress, iconColor = '#84d5b1' }) {
  return (
    <Wrapper>
      <IconWrapper onPress={() => onPress()} bgColor={`${iconColor}30`}>
        <Icon name={icon} iconColor={iconColor}/>
      </IconWrapper>
      <Title>{title}</Title>
    </Wrapper>
  )
}

CourseCategoryGridItem.propTypes = {
  icon: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  onPress: PropTypes.func.isRequired
}

import React from 'react'
import { Container, Content, Tabs, Tab, TabHeading } from 'native-base'
import styled from 'styled-components/native'
import { Ionicons } from '@expo/vector-icons'
import {
  SafeAreaViewWrapper,
  CustomStatusBar,
  ImageProgressComponent,
  CoursePriceTag
} from 'components/ui'
import { TabHeader } from 'components/headers'
import { Title, SubHeading } from 'components/list-items/CourseListItem'
import { CourseLessonsListView, ReviewsListView } from 'components/list-views'
import { defaultStackNavigatorHeaderStyle, tabHeaderStyle } from 'styles/common'
import { SAMPLE_COURSE_LESSONS, SAMPLE_REVIEWS } from 'data/sampleData'
import { StatsWrapper, StatItemWrapper } from './InstructorProfileScreen'

const CourseContentWrapper = styled.View`
  padding: 16px;
`

const CourseTitle = styled.Text`
  width: 300;
  align-self: center;
  font-family: 'SFProDisplayBold';
  font-size: 25;
  text-align: center;
  margin-bottom: 16;
`

const CoursePriceWrapper = styled.View`
  align-self: center;
`

const InstructorProfileWrapper = styled.View`
  flex-direction: row;
  padding: 16px 0px;
  border-color: transparent;
  border-top-color: #dee3ea;
  border-width: 1;
`

const InstructorNameWrapper = styled.View`
  flex: 1;
  justify-content: center;
  margin-left: 16px;
`

const InstructorRatingWrapper = styled.View`
  flex-direction: row;
`

const InstructorRating = styled.Text`
  align-self: center;
  font-family: 'SFProTextBold';
  font-size: 17;
  color: #f7bf00;
  margin-left: 4;
`

export default class CourseDetailsScreen extends React.Component {
  static navigationOptions = {
    title: 'Course Details',
    headerBackTitleVisible: false,
    ...defaultStackNavigatorHeaderStyle
  }

  state = {
    activeTab: 0
  }

  render() {
    const { activeTab } = this.state
    const { navigation } = this.props

    return (
      <SafeAreaViewWrapper>
        <Container>
          <CustomStatusBar />

          <Tabs
            page={activeTab}
            tabBarUnderlineStyle={{ width: null, height: null }}
            onChangeTab={({ i }) => this.setState({ activeTab: i })}
          >
            <Tab
              heading={
                <TabHeading style={tabHeaderStyle}>
                  <TabHeader title="About" active={activeTab === 0} />
                </TabHeading>
              }
            >
              <Content>
                <ImageProgressComponent
                  photoURL="https://imgur.com/rRyGXyP.png"
                  resizeMode="cover"
                  style={{ flex: 1, width: null, height: 200 }}
                />

                <CourseContentWrapper>
                  <CourseTitle>Learn Product Photography</CourseTitle>

                  <CoursePriceWrapper>
                    <CoursePriceTag price="$199.99" />
                  </CoursePriceWrapper>

                  <StatsWrapper>
                    <StatItemWrapper>
                      <Title>5.8k</Title>
                      <SubHeading>Students</SubHeading>
                    </StatItemWrapper>

                    <StatItemWrapper>
                      <Title>4.8</Title>
                      <SubHeading>Rating</SubHeading>
                    </StatItemWrapper>

                    <StatItemWrapper>
                      <Title>27</Title>
                      <SubHeading>Lectures</SubHeading>
                    </StatItemWrapper>
                  </StatsWrapper>

                  <InstructorProfileWrapper>
                    <ImageProgressComponent
                      photoURL="https://i.imgur.com/G2r2WrW.jpg"
                      resizeMode="cover"
                      style={{ width: 50, height: 50 }}
                      imageStyle={{ borderRadius: 25 }}
                    />

                    <InstructorNameWrapper>
                      <Title>Carly Stephen</Title>
                      <SubHeading>Photographer</SubHeading>
                    </InstructorNameWrapper>

                    <InstructorRatingWrapper>
                      <Ionicons
                        name="md-star"
                        size={20}
                        color="#f7bf00"
                        style={{ alignSelf: 'center' }}
                      />
                      <InstructorRating>5.0</InstructorRating>
                    </InstructorRatingWrapper>
                  </InstructorProfileWrapper>

                  <CourseLessonsListView
                    items={SAMPLE_COURSE_LESSONS}
                    onItemPress={item =>
                      navigation.navigate('CourseLesson', {
                        type: item.type
                      })
                    }
                  />
                </CourseContentWrapper>
              </Content>
            </Tab>

            <Tab
              heading={
                <TabHeading style={tabHeaderStyle}>
                  <TabHeader title="Reviews" active={activeTab === 1} />
                </TabHeading>
              }
            >
              <ReviewsListView items={SAMPLE_REVIEWS} />
            </Tab>
          </Tabs>
        </Container>
      </SafeAreaViewWrapper>
    )
  }
}

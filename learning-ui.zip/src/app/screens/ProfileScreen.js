import React from 'react'
import { Container, Content } from 'native-base'
import styled from 'styled-components/native'
import {
  SafeAreaViewWrapper,
  CustomStatusBar,
  ImageProgressComponent,
  ProfileMenuOption
} from 'components/ui'
import { SectionHeader } from 'components/headers'
import { AboutUsModal, AchievementsModal } from 'modals'
import { resetNavigationStack } from 'utils'

const ProfileHeroWrapper = styled.View`
  flex-direction: row;
  padding: 16px;
`

const UserDetailsWrapper = styled.View`
  flex: 1;
  margin-left: 10;
  justify-content: center;
`

const UsernameText = styled.Text`
  font-family: 'SFProTextBold';
  font-size: 17;
`

const PointsText = styled.Text`
  font-family: 'SFProTextRegular';
  font-size: 14;
  color: #8a8a8f;
  margin-top: 4;
`

export default class ProfileScreen extends React.Component {
  state = {
    showAchievementsModal: false,
    showAboutModal: false
  }

  toggleModal(modal) {
    const currentState = this.state[`${modal}`]
    this.setState({
      [`${modal}`]: !currentState
    })
  }

  render() {
    const { showAchievementsModal, showAboutModal } = this.state
    const { navigation } = this.props

    return (
      <SafeAreaViewWrapper>
        <Container>
          <CustomStatusBar />

          <Content>
            <ProfileHeroWrapper>
              <ImageProgressComponent
                photoURL="https://imgur.com/oqgs8nX.png"
                resizeMode="cover"
                style={{ width: 80, height: 80 }}
                imageStyle={{ borderRadius: 40 }}
              />

              <UserDetailsWrapper>
                <UsernameText>Monique Verdugo</UsernameText>
                <PointsText>40,120 points</PointsText>
              </UserDetailsWrapper>
            </ProfileHeroWrapper>

            <SectionHeader>General</SectionHeader>
            <ProfileMenuOption
              showDivider
              iconName="ios-heart"
              iconColor="#f42725"
              text="Saved Courses"
              onPress={() => navigation.navigate('SavedCourses')}
            />
            <ProfileMenuOption
              iconName="ios-trophy"
              iconColor="#f7bf00"
              text="My Achievements"
              onPress={() => this.toggleModal('showAchievementsModal')}
            />

            <SectionHeader>Settings</SectionHeader>
            <ProfileMenuOption
              showDivider
              iconName="ios-information-circle"
              iconColor="#346df1"
              text="About Us"
              onPress={() => this.toggleModal('showAboutModal')}
            />
            <ProfileMenuOption
              iconName="md-log-out"
              iconColor="#000"
              text="Sign Out"
              onPress={() => resetNavigationStack(navigation)}
            />
          </Content>

          {showAchievementsModal && (
            <AchievementsModal
              onDismiss={() => this.toggleModal('showAchievementsModal')}
            />
          )}
          {showAboutModal && (
            <AboutUsModal
              onDismiss={() => this.toggleModal('showAboutModal')}
            />
          )}
        </Container>
      </SafeAreaViewWrapper>
    )
  }
}

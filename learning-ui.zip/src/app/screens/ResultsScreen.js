import React from 'react'
import { Container } from 'native-base'
import { SafeAreaViewWrapper, CustomStatusBar } from 'components/ui'
import { CoursesListView } from 'components/list-views'
import { SAMPLE_SAVED_COURSES } from 'data/sampleData'
import { defaultStackNavigatorHeaderStyle } from 'styles/common'

export default class ResultsScreen extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: navigation.state.params.title,
    headerBackTitleVisible: false,
    ...defaultStackNavigatorHeaderStyle
  })

  render() {
    const { navigation } = this.props

    return (
      <SafeAreaViewWrapper>
        <Container>
          <CustomStatusBar />

          <CoursesListView
            loading={false}
            allowItemSave={false}
            items={SAMPLE_SAVED_COURSES}
            onItemPress={item => navigation.navigate('CourseDetails')}
          />
        </Container>
      </SafeAreaViewWrapper>
    )
  }
}

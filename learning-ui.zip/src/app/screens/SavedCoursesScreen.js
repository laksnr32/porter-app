import React from 'react'
import { Alert } from 'react-native'
import { Container } from 'native-base'
import { SafeAreaViewWrapper, CustomStatusBar } from 'components/ui'
import { CoursesListView } from 'components/list-views'
import { SAMPLE_SAVED_COURSES } from 'data/sampleData'
import { defaultStackNavigatorHeaderStyle } from 'styles/common'

export default class SavedCoursesScreen extends React.Component {
  static navigationOptions = {
    title: 'Saved Courses',
    headerBackTitleVisible: false,
    ...defaultStackNavigatorHeaderStyle
  }

  state = {
    loading: false,
    savedCourses: []
  }

  handleDeleteCourse(item) {
    const { savedCourses: oldValues } = this.state
    const before = oldValues.slice(0, oldValues.indexOf(item))
    const after = oldValues.slice(oldValues.indexOf(item) + 1)

    Alert.alert(
      'Remove Course?',
      'This action cannot be undone. Continue?',
      [
        {
          text: 'Delete',
          onPress: () => {
            this.setState({
              savedCourses: [...before, ...after]
            })
          }
        },
        { text: 'Cancel', style: 'cancel' }
      ],
      { cancelable: false }
    )
  }

  componentDidMount() {
    /* eslint-disable react/no-did-mount-set-state */
    this.setState({ loading: true })

    setTimeout(() => {
      this.setState({
        savedCourses: SAMPLE_SAVED_COURSES,
        loading: false
      })
    }, 1500)
  }

  render() {
    const { loading, savedCourses } = this.state
    const { navigation } = this.props

    return (
      <SafeAreaViewWrapper>
        <Container>
          <CustomStatusBar />

          <CoursesListView
            loading={loading}
            items={savedCourses}
            showItemDelete
            onItemPress={item => navigation.navigate('CourseDetails')}
            onItemSavePress={item => this.handleDeleteCourse(item)}
            onRefresh={() =>
              this.setState({
                savedCourses: SAMPLE_SAVED_COURSES
              })
            }
          />
        </Container>
      </SafeAreaViewWrapper>
    )
  }
}

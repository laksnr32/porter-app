import CourseDetailsScreen from './CourseDetailsScreen'
import CourseLessonScreen from './CourseLessonScreen'
import EditProfileScreen from './EditProfileScreen'
import HomeScreen from './HomeScreen'
import InstructorProfileScreen from './InstructorProfileScreen'
import LandingScreen from './LandingScreen'
import MyCoursesScreen from './MyCoursesScreen'
import ProfileScreen from './ProfileScreen'
import ResultsScreen from './ResultsScreen'
import SavedCoursesScreen from './SavedCoursesScreen'
import SearchScreen from './SearchScreen'
import SignInScreen from './SignInScreen'
import SignUpScreen from './SignUpScreen'

export default {
  CourseDetailsScreen,
  CourseLessonScreen,
  EditProfileScreen,
  HomeScreen,
  InstructorProfileScreen,
  LandingScreen,
  MyCoursesScreen,
  ProfileScreen,
  ResultsScreen,
  SavedCoursesScreen,
  SearchScreen,
  SignInScreen,
  SignUpScreen
}

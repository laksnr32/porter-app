import React from 'react'
import { Container } from 'native-base'
import styled from 'styled-components/native'
import { CustomStatusBar, RegularButton } from 'components/ui'

const TopContentWrapper = styled.View`
  flex: 1;
  padding: 16px;
  justify-content: center;
  align-items: center;
`

const PageTitle = styled.Text`
  font-family: 'SFProDisplayBold';
  font-size: 28;
  text-align: center;
  margin: 32px 16px 8px;
`

const DescriptionText = styled.Text.attrs({
  numberOfLines: 3
})`
  font-family: 'SFProTextRegular';
  font-size: 15;
  color: #8a8a8f;
  text-align: center;
  margin: 0px 16px;
`

const HeroWrapper = styled.View`
  flex: 2;
`

const Hero = styled.Image.attrs({
  source: require('assets/images/profile_hero.png'),
  resizeMode: 'cover'
})`
  flex: 1;
  width: null;
  height: null;
  margin: 0px 0px 16px;
`

const StartButtonWrapper = styled(TopContentWrapper)`
  justify-content: flex-start;
  align-items: stretch;
  margin: 0px 16px;
`

export default class LandingScreen extends React.Component {
  static navigationOptions = {
    headerShown: false
  }

  render() {
    const { navigation } = this.props

    return (
      <Container>
        <CustomStatusBar />

        <TopContentWrapper>
          <PageTitle>Learning App</PageTitle>
          <DescriptionText>
            Unlimited access to thousands of online classes
          </DescriptionText>
        </TopContentWrapper>

        <HeroWrapper>
          <Hero />
        </HeroWrapper>

        <StartButtonWrapper>
          <RegularButton
            text="Get Started"
            onPress={() => navigation.navigate('SignIn')}
          />
        </StartButtonWrapper>
      </Container>
    )
  }
}

import React from 'react'
import { Container } from 'native-base'
import styled from 'styled-components/native'
import { CustomStatusBar } from 'components/ui'
import { FeaturedCoursesListView } from 'components/list-views'
import { CourseCategoriesGridView } from 'components/grid-views'
import {
  SAMPLE_FEATURED_COURSES,
  SAMPLE_COURSE_CATEGORIES,
  SAMPLE_SUBJET_CATEGORIES
} from 'data/sampleData'

const Heading = styled.Text`
  font-family: 'SFProDisplayBold';
  font-size: 15;
  padding: 16px 16px 8px;
  margin-bottom: 10;
`
const Welcome = styled.Text`
  font-family: 'SFProDisplayBold';
  font-size: 25;
  padding: 20px;
  margin: 15px 0px;
`

export default class HomeScreen extends React.Component {
  state = {
    loading: false,
    featuredCourses: []
  }

  componentDidMount() {
    /* eslint-disable react/no-did-mount-set-state */
    this.setState({ loading: true })

    setTimeout(() => {
      this.setState({
        featuredCourses: SAMPLE_FEATURED_COURSES,
        loading: false
      })
    }, 1500)
  }

  render() {
    const { loading, featuredCourses } = this.state
    const { navigation } = this.props

    return (
      <Container>
        <CustomStatusBar />
        <Welcome>Welcome, User</Welcome>
        <CourseCategoriesGridView
          items={SAMPLE_SUBJET_CATEGORIES}
          onItemPress={item =>
            navigation.navigate('Results', {
              title: `${item.title} Courses`
            })
          }
        />
        <Heading>Upcoming Classes</Heading>
        <FeaturedCoursesListView
          loading={loading}
          items={featuredCourses}
          onItemPress={item => navigation.navigate('CourseDetails')}
        />
        
      </Container>
    )
  }
}

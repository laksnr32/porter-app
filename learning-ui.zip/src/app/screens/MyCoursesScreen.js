import React from 'react'
import { Alert } from 'react-native'
import { Container } from 'native-base'
import { CustomStatusBar } from 'components/ui'
import { MyCoursesGridView } from 'components/grid-views'
import { SAMPLE_MY_COURSES } from 'data/sampleData'

export default class MyCoursesScreen extends React.Component {
  state = {
    courses: SAMPLE_MY_COURSES
  }

  handleDeleteCourse(item) {
    const { courses: oldValues } = this.state
    const before = oldValues.slice(0, oldValues.indexOf(item))
    const after = oldValues.slice(oldValues.indexOf(item) + 1)

    const nonEmptyCourses = [...before, ...after].filter(
      course => course.empty !== true
    )

    Alert.alert(
      'Remove Course?',
      'This action cannot be undone. Continue?',
      [
        {
          text: 'Delete',
          onPress: () => {
            this.setState({
              courses: nonEmptyCourses
            })
          }
        },
        { text: 'Cancel', style: 'cancel' }
      ],
      { cancelable: false }
    )
  }

  render() {
    const { courses } = this.state
    const { navigation } = this.props

    return (
      <Container>
        <CustomStatusBar />
        <MyCoursesGridView
          items={courses}
          onItemPress={item => navigation.navigate('CourseDetails')}
          onItemDeletePress={item => this.handleDeleteCourse(item)}
          onRefresh={() => this.setState({ courses: SAMPLE_MY_COURSES })}
        />
      </Container>
    )
  }
}

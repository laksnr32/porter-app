import React from 'react'
import { Video } from 'expo-av'
import { Container, Content } from 'native-base'
import styled from 'styled-components/native'
import { CustomStatusBar, ImageProgressComponent } from 'components/ui'
import { defaultStackNavigatorHeaderStyle } from 'styles/common'

const ArticleHeading = styled.Text`
  font-family: 'SFProTextRegular';
  font-size: 15;
  color: #32ce89;
  margin: 16px;
`

const DescriptionText = styled.Text`
  font-family: 'SFProTextBold';
  font-size: 15;
  margin: 0px 16px 16px;
  line-height: 24;
`

const LessonText = styled(DescriptionText)`
  font-family: 'SFProTextRegular';
  margin: 16px;
  line-height: 24;
`

const VideoPlayer = styled(Video).attrs({
  rate: 1.0,
  volume: 0.5,
  isMuted: false,
  shouldPlay: false,
  isLooping: false,
  useNativeControls: true,
  resizeMode: 'cover'
})`
  width: null;
  height: 250;
  background-color: #8a8a8f;
`

export default class CourseLessonScreen extends React.Component {
  static navigationOptions = {
    title: 'Course Lesson',
    headerBackTitleVisible: false,
    ...defaultStackNavigatorHeaderStyle
  }

  render() {
    const lessonType = this.props.navigation.getParam('type', '')

    return (
      <Container>
        <CustomStatusBar />

        {lessonType === 'article' && (
          <Content>
            <ArticleHeading>About this class</ArticleHeading>
            <DescriptionText>
              Craft the photos you've always imagined with photo editing -
              whether you snap the images with your phone or your DSLR!
            </DescriptionText>

            <ImageProgressComponent
              photoURL="https://imgur.com/G2r2WrW.png"
              resizeMode="cover"
              style={{ width: null, height: 200, margin: 16 }}
            />

            <LessonText>
              In today's age of camera phones and Instagram, everyone is a
              photographer. No matter what type of camera you reach for,
              discover how you can transform your photos with just a few editing
              techniques.
            </LessonText>

            <LessonText>
              Perfect for photography enthusiasts at all levels who want to
              craft the photos you've always imagined with photo editing -
              whether you snap the images with your phone or your DSLR!
            </LessonText>
          </Content>
        )}

        {lessonType === 'video' && (
          <Content style={{ marginVertical: 16 }}>
            <VideoPlayer
              source={{
                uri: 'http://d23dyxeqlo5psv.cloudfront.net/big_buck_bunny.mp4'
              }}
            />

            <ArticleHeading>About this class</ArticleHeading>
            <DescriptionText>
              Craft the photos you've always imagined with photo editing -
              whether you snap the images with your phone or your DSLR!
            </DescriptionText>

            <LessonText>
              In today's age of camera phones and Instagram, everyone is a
              photographer. No matter what type of camera you reach for,
              discover how you can transform your photos with just a few editing
              techniques.
            </LessonText>

            <LessonText>
              Perfect for photography enthusiasts at all levels who want to
              craft the photos you've always imagined with photo editing -
              whether you snap the images with your phone or your DSLR!
            </LessonText>
          </Content>
        )}
      </Container>
    )
  }
}

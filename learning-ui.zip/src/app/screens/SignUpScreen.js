import React from 'react'
import { Container } from 'native-base'
import { SafeAreaViewWrapper, CustomStatusBar } from 'components/ui'
import { SignUpForm } from 'components/forms'
import { onboardingHeaderStyle as headerStyle } from 'styles/common'
import { PageContentWrapper } from './SignInScreen'

export default class SignUpScreen extends React.Component {
  static navigationOptions = {
    title: 'Sign up',
    headerStyle
  }

  state = {
    formLoading: false
  }

  onFormSubmit(values) {
    const { navigation } = this.props

    this.setState({ formLoading: true })

    // const { fullName, email, password } = values

    setTimeout(() => {
      this.setState({ formLoading: false })
      navigation.navigate('Dashboard')
    }, 1500)
  }

  render() {
    const { formLoading } = this.state

    return (
      <SafeAreaViewWrapper extraStyles={{ backgroundColor: '#f5f5f2' }}>
        <Container>
          <CustomStatusBar />

          <PageContentWrapper>
            <SignUpForm
              loading={formLoading}
              onSubmit={values => this.onFormSubmit(values)}
            />
          </PageContentWrapper>
        </Container>
      </SafeAreaViewWrapper>
    )
  }
}

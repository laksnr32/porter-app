import React from 'react'
import { Container } from 'native-base'
import Toast from 'react-native-easy-toast'
import { SafeAreaViewWrapper, CustomStatusBar } from 'components/ui'
import { EditProfileForm } from 'components/forms'
import { defaultStackNavigatorHeaderStyle } from 'styles/common'
import { PageContentWrapper } from './SignInScreen'

export default class EditProfileScreen extends React.Component {
  static navigationOptions = {
    title: 'Edit Profile',
    headerBackTitleVisible: false,
    ...{
      ...defaultStackNavigatorHeaderStyle,
      ...{
        headerStyle: {
          backgroundColor: '#f5f5f2',
          borderBottomColor: 'transparent'
        }
      }
    }
  }

  state = {
    formLoading: false
  }

  onFormSubmit(values) {
    this.setState({ formLoading: true })

    // const { fullName, email, password } = values

    setTimeout(() => {
      this.setState({ formLoading: false })
      this.refs.toast.show('Your profile details have been updated', 2000)
    }, 1500)
  }

  render() {
    const { formLoading } = this.state

    return (
      <SafeAreaViewWrapper extraStyles={{ backgroundColor: '#f5f5f2' }}>
        <Container>
          <CustomStatusBar />

          <PageContentWrapper>
            <EditProfileForm
              loading={formLoading}
              onSubmit={values => this.onFormSubmit(values)}
            />
          </PageContentWrapper>

          <Toast
            ref="toast"
            position="center"
            textStyle={{
              fontFamily: 'SFProTextBold',
              fontSize: 14,
              color: '#fff'
            }}
          />
        </Container>
      </SafeAreaViewWrapper>
    )
  }
}

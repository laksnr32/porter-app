import React from 'react'
import { Container } from 'native-base'
import {
  SafeAreaViewWrapper,
  CustomStatusBar,
  ImageProgressComponent
} from 'components/ui'
import { Title, SubHeading } from 'components/list-items/CourseListItem'
import { CoursesListView } from 'components/list-views'
import styled from 'styled-components/native'
import { defaultStackNavigatorHeaderStyle } from 'styles/common'
import { SAMPLE_INSTRUCTOR_COURSES } from 'data/sampleData'

const AvatarWrapper = styled.View`
  align-items: center;
  margin-top: 16;
`

export const StatsWrapper = styled.View`
  height: 80;
  flex-direction: row;
`

export const StatItemWrapper = styled.View`
  flex: 1;
  justify-content: center;
  align-items: center;
`

const CourseListWrapper = styled.View`
  flex: 1;
  background-color: #f5f5f2;
`

export default class InstructorProfileScreen extends React.Component {
  static navigationOptions = {
    title: 'Instructor Profile',
    headerBackTitleVisible: false,
    ...defaultStackNavigatorHeaderStyle
  }

  state = {
    courses: SAMPLE_INSTRUCTOR_COURSES
  }

  handleSaveCourse(item) {
    const { courses } = this.state
    const newCourses = courses.map(course => {
      if (course === item) {
        course.saved = !course.saved
      }

      return course
    })

    this.setState({
      courses: newCourses
    })
  }

  render() {
    const { courses } = this.state
    const { navigation } = this.props

    return (
      <SafeAreaViewWrapper extraStyles={{ backgroundColor: '#f5f5f2' }}>
        <Container>
          <CustomStatusBar />

          <AvatarWrapper>
            <ImageProgressComponent
              photoURL="https://i.imgur.com/G2r2WrW.jpg"
              resizeMode="cover"
              style={{ width: 80, height: 80, marginBottom: 8 }}
              imageStyle={{ borderRadius: 40 }}
            />

            <Title>Carly Stephen</Title>
            <SubHeading>Instructor</SubHeading>
          </AvatarWrapper>

          <StatsWrapper>
            <StatItemWrapper>
              <Title>20</Title>
              <SubHeading>Courses</SubHeading>
            </StatItemWrapper>

            <StatItemWrapper>
              <Title>5.0</Title>
              <SubHeading>Rating</SubHeading>
            </StatItemWrapper>

            <StatItemWrapper>
              <Title>12k</Title>
              <SubHeading>Students</SubHeading>
            </StatItemWrapper>
          </StatsWrapper>

          <CourseListWrapper>
            <CoursesListView
              loading={false}
              items={courses}
              onItemPress={item => navigation.navigate('CourseDetails')}
              onItemSavePress={item => this.handleSaveCourse(item)}
            />
          </CourseListWrapper>
        </Container>
      </SafeAreaViewWrapper>
    )
  }
}

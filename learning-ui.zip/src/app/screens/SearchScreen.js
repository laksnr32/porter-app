import React from 'react'
import { Slider } from 'react-native'
import { Container, Content } from 'native-base'
import styled from 'styled-components/native'
import {
  CustomStatusBar,
  CustomActivityIndicator,
  RegularButton
} from 'components/ui'
import { AvatarsListView, RecommendedListView } from 'components/list-views'
import { SAMPLE_AVATARS, SAMPLE_COURSE_CATEGORIES, SAMPLE_SUBJET_CATEGORIES } from 'data/sampleData'

const Heading = styled.Text`
  font-family: 'SFProDisplayBold';
  font-size: 15;
  padding: 16px 16px 8px;
  margin-bottom: 8;
`

const PricingWrapper = styled.View`
  flex-direction: row;
  padding: 0px 16px;
`

const SliderWrapper = styled.View`
  flex: 1;
  margin-right: 16;
`

const PriceWrapper = styled.View`
  justify-content: center;
`

const PriceSlider = styled(Slider).attrs({
  step: 5,
  trackStyle: { backgroundColor: '#dee3ea' },
  thumbStyle: { backgroundColor: '#32ce89' },
  minimumTrackTintColor: '#32ce89',
  thumbTintColor: '#32ce89',
  maximumValue: 100,
  minimumValue: 10
})``

const PriceText = styled.Text`
  font-family: 'SFProTextBold';
  font-size: 17;
`

const ButtonWrapper = styled.View`
  margin: 0px 16px;
`

export default class SearchScreen extends React.Component {
  state = {
    price: 30,
    loading: false
  }

  applyAndSearch() {
    const { navigation } = this.props
    this.setState({ loading: true })

    setTimeout(() => {
      this.setState({
        loading: false
      })
      navigation.navigate('Results', {
        title: 'Results'
      })
    }, 1500)
  }

  render() {
    const { price, loading } = this.state
    const { navigation } = this.props

    return (
      <Container>
        <CustomStatusBar />

        <Content>
          <Heading>Top Instructors</Heading>
          <AvatarsListView
            items={SAMPLE_AVATARS}
            onItemPress={item => navigation.navigate('InstructorProfile')}
          />

          <Heading>Recommended</Heading>
          <RecommendedListView
            items={SAMPLE_SUBJET_CATEGORIES}
            onItemPress={item =>
              navigation.navigate('Results', {
                title: `${item.title} Courses`
              })
            }
          />

          <Heading>Pricing</Heading>
          <PricingWrapper>
            <SliderWrapper>
              <PriceSlider
                value={price}
                onValueChange={value => this.setState({ price: value })}
              />
            </SliderWrapper>

            <PriceWrapper>
              <PriceText>${price}</PriceText>
            </PriceWrapper>
          </PricingWrapper>

          <ButtonWrapper>
            <RegularButton text="Apply" onPress={() => this.applyAndSearch()} />
          </ButtonWrapper>
        </Content>

        {loading && <CustomActivityIndicator />}
      </Container>
    )
  }
}

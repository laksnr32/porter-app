import { createAppContainer, createSwitchNavigator } from 'react-navigation'
import { createDrawerNavigator } from 'react-navigation-drawer'
import { createStackNavigator } from 'react-navigation-stack'
import { createBottomTabNavigator } from 'react-navigation-tabs'
import Screens from 'screens'
import { defaultStackNavigatorHeaderStyle, tabBarOptions } from 'styles/common'
import {
  getDashboardNavigatorHeaderTitle,
  getDashboardNavigatorTabIconName,
  getNavigationHeaderRight,
  getNavigationDrawerMenuButton
} from 'utils'
import { gradientText, gradientPrimary, drawerItemStyle, gradientSecondary } from 'styles/common';
import NativeBaseDrawer from 'components/drawer/NativeBaseDrawer';

const MainStackNavigator = createStackNavigator(
  {
    Landing: Screens.LandingScreen,
    SignIn: Screens.SignInScreen,
    SignUp: Screens.SignUpScreen
  },
  {
    defaultNavigationOptions: {
      headerBackTitleVisible: false,
      ...defaultStackNavigatorHeaderStyle
    }
  }
)

const DashboardTabNavigator = createBottomTabNavigator(
  {
    Home: Screens.HomeScreen,
    MyCourses: Screens.MyCoursesScreen,
    Search: Screens.SearchScreen,
    Profile: Screens.ProfileScreen
  },
  {
    defaultNavigationOptions: ({ navigation }) => {
      return {
        tabBarIcon: ({ tintColor }) =>
          getDashboardNavigatorTabIconName(navigation, tintColor)
      }
    },
    navigationOptions: ({ navigation }) => {
      return {
        headerTitle: getDashboardNavigatorHeaderTitle(navigation),
        headerRight: () => getNavigationHeaderRight(navigation),
        gestureEnabled: false,
        headerBackTitleVisible: false,
        ...defaultStackNavigatorHeaderStyle
      }
    },
    tabBarOptions
  }
)

const DashboardDrawerNavigator = createDrawerNavigator({
    Home: {
      screen:  Screens.HomeScreen,
    },
    MyCourses: {
      screen: Screens.MyCoursesScreen,
    },
    Search: {
      screen:  Screens.SearchScreen,
    },
    Profile: {
      screen:  Screens.ProfileScreen,
    }
  },
  {
    initialRouteName: "Home",
    contentComponent: NativeBaseDrawer,
    contentOptions: {
      activeTintColor: gradientText,
      inactiveTintColor : gradientPrimary,           
    },
    navigationOptions: ({ navigation }) => {
      return {
        headerTitle: getDashboardNavigatorHeaderTitle(navigation),        
        headerRight: () => getNavigationHeaderRight(navigation), 
        headerLeft:  () => getNavigationDrawerMenuButton(navigation),      
        ...defaultStackNavigatorHeaderStyle
      }
    }    
  }
);



const DashboardStackNavigator = createStackNavigator({
  //DashboardTabNavigator,
  DashboardDrawerNavigator,
  SavedCourses: Screens.SavedCoursesScreen,
  EditProfile: Screens.EditProfileScreen,
  InstructorProfile: Screens.InstructorProfileScreen,
  Results: Screens.ResultsScreen,
  CourseDetails: Screens.CourseDetailsScreen,
  CourseLesson: Screens.CourseLessonScreen
})

const AppNavigator = createSwitchNavigator({
  MainStackNavigator,
  Dashboard: DashboardStackNavigator
})

const AppContainer = createAppContainer(AppNavigator)

export default AppContainer

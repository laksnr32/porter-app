import React from 'react'
import { Feather } from '@expo/vector-icons'
import { gradientText } from 'styles/common'
const onIconPress = (navigation) => {
  navigation.toggleDrawer();
}

export default function getNavigationDrawerMenuButton(navigation) {
  
  return (
    <Feather
      name={'menu'}
      color={gradientText}
      size={20}
      style={{ marginLeft: 16 }}
      onPress={() => onIconPress(navigation)}
    />
  )
}

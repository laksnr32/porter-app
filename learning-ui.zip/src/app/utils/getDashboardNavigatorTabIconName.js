import React from 'react'
import { Ionicons } from '@expo/vector-icons'

export default function getDashboardNavigatorTabIconName(
  navigation,
  tintColor
) {
  const { routeName } = navigation.state
  let iconName

  if (routeName === 'Home') {
    iconName = 'ios-home'
  } else if (routeName === 'MyCourses') {
    iconName = 'ios-school'
  } else if (routeName === 'Search') {
    iconName = 'ios-search'
  } else if (routeName === 'Profile') {
    iconName = 'ios-more'
  }

  return <Ionicons name={iconName} color={tintColor} size={25} />
}

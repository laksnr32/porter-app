import React from 'react'
import PropTypes from 'prop-types'
import { Modal } from 'react-native'
import styled from 'styled-components/native'
import { RegularButton } from 'components/ui'

const Hero = styled.Image.attrs({
  source: require('assets/images/profile_hero.png'),
  resizeMode: 'cover'
})`
  width: 100%;
  height: 300;
  margin: 0px 0px 16px;
`

const Title = styled.Text`
  font-family: 'SFProDisplayBold';
  font-size: 25;
  margin: 16px;
`

const AboutText = styled.Text`
  font-family: 'SFProTextRegular';
  font-size: 15;
  color: #8a8a8f;
  margin: 0px 16px;
  line-height: 24;
`

const ButtonWrapper = styled.View`
  margin: 0px 16px;
`

export default function AboutUsModal({ onDismiss }) {
  return (
    <Modal visible animationType="slide" onRequestClose={() => null}>
      <Hero />

      <Title>Learning App</Title>
      <AboutText>
        Learning App gives you unlimited access to thousands of online classes.
        {`\n\n`}
        We make it easy for you to explore a variety of fresh topics, find the
        right instructor for you, and even learn on your schedule.
      </AboutText>

      <ButtonWrapper>
        <RegularButton text="Nice!" onPress={() => onDismiss()} />
      </ButtonWrapper>
    </Modal>
  )
}

AboutUsModal.propTypes = {
  onDismiss: PropTypes.func.isRequired
}

import AboutUsModal from './AboutUsModal'
import AchievementsModal from './AchievementsModal'

export { AboutUsModal, AchievementsModal }

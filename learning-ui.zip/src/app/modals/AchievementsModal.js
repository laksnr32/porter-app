import React from 'react'
import PropTypes from 'prop-types'
import { Modal } from 'react-native'
import styled from 'styled-components/native'
import { RegularButton } from 'components/ui'

const Wrapper = styled.View`
  flex: 1;
  justify-content: center;
  align-items: center;
`

const Hero = styled.Image.attrs({
  source: require('assets/images/confetti.png')
})`
  width: 125;
  height: 125;
  align-self: center;
`

const Heading = styled.Text`
  font-family: 'SFProDisplayBold';
  font-size: 25;
  color: #32ce89;
  text-align: center;
  margin: 16px 0px;
`

const SubHeading = styled.Text`
  font-family: 'SFProTextRegular';
  font-size: 15;
  text-align: center;
`

const CourseTitle = styled.Text`
  width: 180;
  font-family: 'SFProTextBold';
  font-size: 15;
  text-align: center;
  margin: 16px 0px;
`

const ButtonWrapper = styled.View`
  margin: 0px 16px;
  align-self: stretch;
`

export default function AchievementsModal({ onDismiss }) {
  return (
    <Modal visible animationType="slide" onRequestClose={() => null}>
      <Wrapper>
        <Hero />

        <Heading>Congratulations!</Heading>
        <SubHeading>You completed</SubHeading>

        <CourseTitle>"Model photography for beginners"</CourseTitle>

        <ButtonWrapper>
          <RegularButton text="Yay!" onPress={() => onDismiss()} />
        </ButtonWrapper>
      </Wrapper>
    </Modal>
  )
}

AchievementsModal.propTypes = {
  onDismiss: PropTypes.func.isRequired
}

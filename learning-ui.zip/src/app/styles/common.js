import React from 'react'
import { Platform, View, StyleSheet } from 'react-native'
import styled from 'styled-components'
import { Ionicons } from '@expo/vector-icons'
import { LinearGradient } from 'expo-linear-gradient';
import { Header } from 'react-navigation-stack';

export const gradientPrimary = '#9b63f8';
export const gradientSecondary = '#809ffc';
//export const gradientColors = ['#9b63f8', '#f07da890'];
export const gradientText = '#fff';
export const gradientContrast = '#f07da8';

const HeaderBackImageWrapper = styled.View`
  width: 35;
  justify-content: center;
  align-items: center;
  margin-left: ${Platform.OS === 'ios' ? 8 : 0};
`

export const safeAreaViewStyle = {
  flex: 1
}

export const onboardingHeaderStyle = {
  backgroundColor: '#f5f5f2',
  borderBottomColor: 'transparent'
}

const headerTitleStyle = {
  fontFamily: 'SFProDisplayBold',
  fontSize: 20,
  color: gradientText,
}

export const drawerItemStyle = {
  fontFamily: 'SFProTextBold',
  fontSize: 15,
  padding: 10,
}

export const defaultStackNavigatorHeaderStyle = {
  headerStyle: {
    //backgroundColor: 'transparent',
    borderBottomColor: 'transparent'
  }, 
  headerBackground: () => (
    <LinearGradient
      colors={[`${gradientPrimary}`, `${gradientSecondary}`]}
      style={{ flex: 1 }}
      start={[0,1]}
      end={[1,0]}
    />
  ),
  headerTitleStyle,
  headerTintColor: gradientText,
  headerBackTitleStyle: headerTitleStyle,
  headerBackImage: ({ tintColor }) => (
    <HeaderBackImageWrapper>
      <Ionicons name="md-arrow-round-back" color={tintColor} size={30} />
    </HeaderBackImageWrapper>
  )
}

export const tabHeaderStyle = {
  backgroundColor: '#fff'
}

export const tabBarOptions = {
  activeTintColor: '#32ce89',
  inactiveTintColor: 'grey',
  showLabel: false,
  style: {
    backgroundColor: '#fff',
    borderTopColor: '#dee3ea'
  }
}

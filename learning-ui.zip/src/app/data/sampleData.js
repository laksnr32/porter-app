export const SAMPLE_COURSE_CATEGORIES = [
  { icon: 'ios-briefcase', title: 'Business' },
  { icon: 'logo-dribbble', title: 'Design' },
  { icon: 'ios-analytics', title: 'Economy' },
  { icon: 'logo-bitcoin', title: 'Crypto' },
  { icon: 'logo-youtube', title: 'Video' },
  { icon: 'ios-basketball', title: 'Sports' }
]

export const SAMPLE_SUBJET_CATEGORIES = [
  { icon: 'sort-alphabetical', title: 'English', iconColor: '#6cdabd'},
  { icon: 'math-compass', title: 'Mathematics', iconColor: '#dc92e7'},
  { icon: 'scale', title: 'Physics', iconColor: '#f7a154'},
  { icon: 'flask-outline', title: 'Chemistry', iconColor: '#60c6ff'},
  { icon: 'football', title: 'Sports', iconColor: '#f17e83'},
  { icon: 'laptop-chromebook', title: 'Computer', iconColor: '#6cdabd'},
]

export const SAMPLE_AVATARS = [
  {
    photoURL: 'https://imgur.com/8buCY6D.png',
    title: 'Ava',
    category: 'Modelling'
  },
  {
    photoURL: 'https://imgur.com/xzTSKke.png',
    title: 'William',
    category: 'Business'
  },
  {
    photoURL: 'https://imgur.com/xlLK8bN.png',
    title: 'Sophia',
    category: 'Fashion'
  },
  {
    photoURL: 'https://imgur.com/5A5nOnQ.png',
    title: 'Queen',
    category: 'Marketing'
  },
  {
    photoURL: 'https://imgur.com/wCd1GtK.png',
    title: 'Liam',
    category: 'Sports'
  },
  {
    photoURL: 'https://imgur.com/Nsrj3TY.png',
    title: 'Jacob',
    category: 'Music'
  }
]

export const SAMPLE_FEATURED_COURSES = [
  {
    title: 'Learn Product Photography - The Right Way',
    price: '$29.99',
    photoURL: 'https://imgur.com/rRyGXyP.png'
  },
  {
    title: 'Flower arrangements like a Pro!',
    price: '$19.99',
    originalPrice: '$29.99',
    photoURL: 'https://imgur.com/lu3RVHY.png'
  },
  {
    title: 'Introduction to Football (Soccer) Tactics',
    price: '$9.99',
    originalPrice: '$19.99',
    photoURL: 'https://imgur.com/NLccF0H.png'
  },
  {
    title: 'Learn How 2 Dance - Salsa (Beginner)',
    price: '$10.99',
    photoURL: 'https://imgur.com/VXp5sUc.png'
  },
  {
    title: 'Meal Planning Masterclass: Create Your Own Meal Plan',
    price: '$10.99',
    photoURL: 'https://imgur.com/9yxW634.png'
  }
]

export const SAMPLE_MY_COURSES = [
  {
    photoURL: 'https://imgur.com/PbjJEnR.png',
    title: 'HTML & CSS for beginners',
    length: 15,
    progress: 10
  },
  {
    photoURL: 'https://imgur.com/a3JZimG.png',
    title: 'Travel Photography',
    length: 24,
    progress: 8
  },
  {
    photoURL: 'https://imgur.com/kaCoi9t.png',
    title: 'Home Gardening',
    length: 12,
    progress: 10
  },
  {
    photoURL: 'https://imgur.com/rRyGXyP.png',
    title: 'Learn Product Photography - The Right Way',
    length: 16,
    progress: 5
  },
  {
    photoURL: 'https://imgur.com/lu3RVHY.png',
    title: 'Flower arrangements',
    length: 26,
    progress: 7
  },
  {
    photoURL: 'https://imgur.com/VXp5sUc.png',
    title: 'Learn How 2 Dance',
    length: 20,
    progress: 3
  },
  {
    photoURL: 'https://imgur.com/NLccF0H.png',
    title: 'Introduction to Football (Soccer) Tactics',
    length: 28,
    progress: 10
  },
  {
    photoURL: 'https://imgur.com/9yxW634.png',
    title: 'Meal Planning Masterclass',
    length: 32,
    progress: 4
  }
]

export const SAMPLE_SAVED_COURSES = [
  {
    title: 'Travel Photography',
    price: '$29.99',
    photoURL: 'https://imgur.com/a3JZimG.png',
    students: '1,180',
    lectures: '24',
    category: 'Photography',
    saved: true
  },

  {
    title: 'Introduction to Football (Soccer) Tactics',
    price: '$1.99',
    photoURL: 'https://imgur.com/NLccF0H.png',
    students: '820',
    lectures: '16',
    category: 'Sports',
    saved: true
  },
  {
    title: 'Home Gardening',
    price: '$19.99',
    photoURL: 'https://imgur.com/kaCoi9t.png',
    students: '580',
    lectures: '26',
    category: 'Nature',
    saved: true
  },
  {
    title: 'Learn How 2 Dance - Salsa (Beginner)',
    price: '$10.99',
    photoURL: 'https://imgur.com/VXp5sUc.png',
    students: '80',
    lectures: '16',
    category: 'Dance',
    saved: true
  },
  {
    title: 'Meal Planning Masterclass: Create Your Own Meal Plan',
    price: '$10.99',
    photoURL: 'https://imgur.com/9yxW634.png',
    students: '900',
    lectures: '10',
    category: 'Nutrition',
    saved: true
  }
]

export const SAMPLE_INSTRUCTOR_COURSES = [
  {
    photoURL: 'https://imgur.com/PbjJEnR.png',
    title: 'HTML & CSS for beginners',
    price: '$29.99',
    students: '1,180',
    lectures: '24',
    category: 'Software',
    saved: true
  },

  {
    photoURL: 'https://imgur.com/rRyGXyP.png',
    title: 'Learn Product Photography - The Right Way',
    price: '$1.99',
    students: '820',
    lectures: '16',
    category: 'Photography',
    saved: false
  },
  {
    title: 'Home Gardening',
    price: '$19.99',
    photoURL: 'https://imgur.com/kaCoi9t.png',
    students: '580',
    lectures: '26',
    category: 'Nature',
    saved: false
  },
  {
    title: 'Meal Planning Masterclass: Create Your Own Meal Plan',
    price: '$10.99',
    photoURL: 'https://imgur.com/9yxW634.png',
    students: '900',
    lectures: '10',
    category: 'Nutrition',
    saved: true
  },
  {
    photoURL: 'https://imgur.com/lu3RVHY.png',
    title: 'Flower arrangements',
    price: '$10.99',
    students: '900',
    lectures: '10',
    category: 'Decoration',
    saved: false
  }
]

export const SAMPLE_REVIEWS = [
  {
    title: 'Martin Moss',
    category: 'Student',
    date: '1h ago',
    review:
      'Amazing course! I learned a lot of things about photography in the shortest amount of time',
    photoURL: 'https://imgur.com/TY95v7h.png',
    rating: 5
  },
  {
    title: 'Katie Shall',
    category: 'Student',
    date: '1d ago',
    review: 'Really experienced photographer. Love it!',
    photoURL: 'https://imgur.com/G2r2WrW.png',
    rating: 4
  },
  {
    title: 'Ava Simone',
    category: 'Instructor',
    date: '2d ago',
    review: 'Interesting takes on lighting and gradients...',
    photoURL: 'https://imgur.com/8buCY6D.png',
    rating: 4
  },
  {
    title: 'Tom Williams',
    category: 'Instructor',
    date: '1w ago',
    review: 'Short and straight to the point!',
    photoURL: 'https://imgur.com/xzTSKke.png',
    rating: 5
  },
  {
    title: 'Monique Verdugo',
    category: 'Student',
    date: '2w ago',
    review: "I'm new here...Loving it!",
    photoURL: 'https://imgur.com/oqgs8nX.png',
    rating: 5
  }
]

export const SAMPLE_COURSE_LESSONS = [
  {
    title: 'Introduction',
    description: 'An overview of this course.',
    type: 'video'
  },
  {
    title: 'What is Product Photography?',
    description: 'Basic introduction.',
    type: 'article'
  },
  {
    title: 'Trends in Product Photography?',
    description: 'Information about trends in the industry.',
    type: 'article'
  },
  {
    title: 'Tools for Product Photography?',
    description: 'Know your equipment.',
    type: 'video'
  },
  {
    title: 'Other Resources',
    description: 'Explore the world of product photography.',
    type: 'video'
  }
]

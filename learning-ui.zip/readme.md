# Learning Masterz

## Development Environment Setup

### Software Required
* node
* expo client app in android or Ios mobile
* Visual studio code For Code Editing

### Running the app

```npm install```

```npm start```
### This will open metro builder with QR Code to scan in expo cliient mobile Application.